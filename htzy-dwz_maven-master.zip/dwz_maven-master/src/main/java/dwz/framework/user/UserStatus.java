package dwz.framework.user;

public enum UserStatus {
	PENDING,ACTIVE,INACTIVE,DELETED
}
