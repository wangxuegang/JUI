package dwz.business.task;


public class CleanUpDBTask implements Runnable  {

	public void run() {
		System.out.println("Start CleanUpDBTask...");
	}

}
