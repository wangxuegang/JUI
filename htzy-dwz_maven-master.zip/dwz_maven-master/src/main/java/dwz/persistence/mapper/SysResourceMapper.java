package dwz.persistence.mapper;

import dwz.dal.BaseMapper;
import dwz.persistence.beans.SysResource;
import org.springframework.stereotype.Repository;

@Repository
public interface SysResourceMapper extends BaseMapper<SysResource,Integer>{
	

}
