package dwz.persistence.mapper;

import dwz.dal.BaseMapper;
import dwz.persistence.beans.SysPermission;
import org.springframework.stereotype.Repository;

@Repository
public interface SysPermissionMapper extends BaseMapper<SysPermission,Integer>{
	

}
