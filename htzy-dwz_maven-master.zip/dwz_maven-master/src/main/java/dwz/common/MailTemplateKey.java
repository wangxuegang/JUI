package dwz.common;

public enum MailTemplateKey {
	defaultVm, verifyEmail, registerConfirm, emailToFriend, forgetPassword
}
