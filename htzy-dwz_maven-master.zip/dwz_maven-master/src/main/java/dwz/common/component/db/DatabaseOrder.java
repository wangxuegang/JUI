package dwz.common.component.db;

/**
 * 数据库排序关键字
 */
public enum DatabaseOrder {
	asc, desc
}
