package dwz.common.component.queue;

/**
 * 出队方式(用于扩展)
 * @author liqiang
 */
public interface GetMethod {

}
