package dwz.dal.common.sequence.dao;

import dwz.dal.BaseMapper;

public interface IdSequenceDao extends BaseMapper<DalSequenceDO, String> {
	
}
