import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Created by ShiheHuang on 2015/10/28.
 */
public class PiConnectTest {
    public static void main(String args[]){
        String url = "jdbc:odbc:PiOdbc";
        Connection conn;
        Statement stmt;
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            conn = DriverManager.getConnection(url, "piadmin", "");
            System.out.println(conn);
            stmt = conn.createStatement();
            String sql = "select count(*) from PIcomp where tag = 'szlstph1ua' and time <= DATE('today')";
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            int count = rs.getInt(1);
            System.out.println(count);
        } catch (Exception e) {
            System.err.print("Error" + e.getMessage());
        }
    }
}
